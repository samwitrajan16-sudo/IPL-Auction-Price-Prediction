from pathlib import Path
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.anova import anova_lm
from statsmodels.stats.diagnostic import het_breuschpagan

from .data_preprocessing import load_data

def main():
    df = load_data()
    y = df["Auction_Price_Cr"]

    X_a = sm.add_constant(df[["Runs", "Strike_Rate", "Boundaries"]])
    X_b = sm.add_constant(df[["Runs", "Strike_Rate", "Boundaries", "New_Variable"]])

    model_a = sm.OLS(y, X_a).fit()
    model_b = sm.OLS(y, X_b).fit()

    print("=== Nested Model F-test ===")
    print(anova_lm(model_a, model_b))

    f_stat, p_value = model_b.compare_f_test(model_a)
    print(f"F-statistic: {f_stat:.4f}")
    print(f"p-value: {p_value:.6f}")

    print("\n=== R-squared comparison ===")
    print(f"Baseline R2: {model_a.rsquared:.4f}")
    print(f"Extended R2: {model_b.rsquared:.4f}")
    print(f"Baseline Adjusted R2: {model_a.rsquared_adj:.4f}")
    print(f"Extended Adjusted R2: {model_b.rsquared_adj:.4f}")

    print("\n=== Breusch-Pagan test (extended model) ===")
    bp = het_breuschpagan(model_b.resid, model_b.model.exog)
    labels = ["LM statistic", "LM p-value", "F statistic", "F p-value"]
    print(dict(zip(labels, bp)))

if __name__ == "__main__":
    main()
