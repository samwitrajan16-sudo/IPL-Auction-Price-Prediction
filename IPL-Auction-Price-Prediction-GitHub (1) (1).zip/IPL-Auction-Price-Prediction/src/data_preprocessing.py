from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "ipl_players.csv"

def load_data(path=DATA_PATH):
    df = pd.read_csv(path)
    required = [
        "Player", "Runs", "Strike_Rate", "Boundaries",
        "Experience_Years", "New_Variable", "Auction_Price_Cr"
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df.dropna().copy()

if __name__ == "__main__":
    data = load_data()
    print(data.head())
    print("\nShape:", data.shape)
