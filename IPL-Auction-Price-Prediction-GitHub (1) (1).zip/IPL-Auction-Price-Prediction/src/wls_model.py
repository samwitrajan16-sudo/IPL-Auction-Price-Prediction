from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

from .data_preprocessing import load_data

ROOT = Path(__file__).resolve().parents[1]
VIZ = ROOT / "visualizations"
VIZ.mkdir(exist_ok=True)

def main():
    df = load_data()
    features = ["Runs", "Strike_Rate", "Boundaries", "New_Variable"]
    X = sm.add_constant(df[features])
    y = df["Auction_Price_Cr"]

    ols = sm.OLS(y, X).fit()

    # Practical variance model: estimate variance from absolute OLS residuals
    # and use inverse squared scale as WLS weights.
    scale = np.maximum(np.abs(ols.resid), 0.05)
    weights = 1 / (scale ** 2)

    wls = sm.WLS(y, X, weights=weights).fit()

    print("=== OLS ===")
    print(f"R2: {ols.rsquared:.4f}")
    print(f"Adjusted R2: {ols.rsquared_adj:.4f}")

    print("\n=== WLS ===")
    print(f"R2: {wls.rsquared:.4f}")
    print(f"Adjusted R2: {wls.rsquared_adj:.4f}")
    print("\nWLS summary:")
    print(wls.summary())

    plt.figure(figsize=(8, 5))
    plt.scatter(ols.fittedvalues, ols.resid, alpha=0.7)
    plt.axhline(0, linestyle="--")
    plt.xlabel("Fitted Values")
    plt.ylabel("OLS Residuals")
    plt.title("Residual Plot — OLS")
    plt.tight_layout()
    plt.savefig(VIZ / "residual_plot.png", dpi=200)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.scatter(y, wls.fittedvalues, alpha=0.7)
    lo, hi = min(y.min(), wls.fittedvalues.min()), max(y.max(), wls.fittedvalues.max())
    plt.plot([lo, hi], [lo, hi], linestyle="--")
    plt.xlabel("Actual Auction Price (Cr)")
    plt.ylabel("Predicted Auction Price (Cr)")
    plt.title("Actual vs Predicted — WLS")
    plt.tight_layout()
    plt.savefig(VIZ / "actual_vs_predicted_wls.png", dpi=200)
    plt.close()

if __name__ == "__main__":
    main()
