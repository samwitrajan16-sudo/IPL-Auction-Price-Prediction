from pathlib import Path
import pandas as pd
import statsmodels.api as sm
from sklearn.metrics import mean_squared_error

from .data_preprocessing import load_data

ROOT = Path(__file__).resolve().parents[1]
VIZ = ROOT / "visualizations"
VIZ.mkdir(exist_ok=True)

def fit_model(df, features):
    X = sm.add_constant(df[features])
    y = df["Auction_Price_Cr"]
    return sm.OLS(y, X).fit()

def main():
    df = load_data()

    baseline_features = ["Runs", "Strike_Rate", "Boundaries"]
    extended_features = baseline_features + ["New_Variable"]

    baseline = fit_model(df, baseline_features)
    extended = fit_model(df, extended_features)

    print("=== Baseline OLS ===")
    print(baseline.summary())
    print("\n=== Extended OLS ===")
    print(extended.summary())

    for name, model in [("Baseline", baseline), ("Extended", extended)]:
        pred = model.predict()
        rmse = mean_squared_error(df["Auction_Price_Cr"], pred) ** 0.5
        print(f"{name}: R2={model.rsquared:.4f}, "
              f"Adj_R2={model.rsquared_adj:.4f}, RMSE={rmse:.4f}")

if __name__ == "__main__":
    main()
