# IPL Auction Price Prediction

A regression and statistical analysis project for modelling IPL player auction prices from player-performance variables.

> **Dataset note:** `data/ipl_players.csv` is a synthetic demonstration dataset created for this GitHub project. Replace it with a properly sourced IPL dataset if you want to use real auction data, and update the dataset citation in this README.

## Objectives
- Explore relationships between player performance and auction price.
- Build a multiple linear regression baseline.
- Compare a baseline model with an extended model using an additional variable.
- Use an F-test, R² and Adjusted R² to assess incremental model fit.
- Diagnose heteroscedasticity using residual analysis and the Breusch–Pagan test.
- Fit a Weighted Least Squares (WLS) model to address non-constant error variance.
- Compare model metrics and generate publication-ready plots.

## Project Structure
```text
IPL-Auction-Price-Prediction/
├── data/
│   └── ipl_players.csv
├── notebooks/
│   └── IPL_Auction_Price_Analysis.ipynb
├── src/
│   ├── data_preprocessing.py
│   ├── regression_model.py
│   ├── statistical_testing.py
│   └── wls_model.py
├── visualizations/
├── requirements.txt
├── README.md
└── .gitignore
```

## Variables
- `Runs`: runs scored
- `Strike_Rate`: batting strike rate
- `Boundaries`: number of boundaries
- `Experience_Years`: player experience
- `New_Variable`: additional predictor used for model comparison
- `Auction_Price_Cr`: auction price in crore units

## Methodology
1. Load and validate the data.
2. Perform exploratory analysis and correlation checks.
3. Fit **Model A**:
   `Auction_Price_Cr ~ Runs + Strike_Rate + Boundaries`
4. Fit **Model B**:
   `Auction_Price_Cr ~ Runs + Strike_Rate + Boundaries + New_Variable`
5. Compare Model A and Model B using R², Adjusted R² and an F-test.
6. Diagnose heteroscedasticity with residual plots and the Breusch–Pagan test.
7. Fit WLS using inverse estimated residual variance as weights.
8. Compare OLS and WLS results.

## Run the Project

```bash
pip install -r requirements.txt
python -m src.regression_model
python -m src.statistical_testing
python -m src.wls_model
```

Or open the notebook:

```bash
jupyter notebook notebooks/IPL_Auction_Price_Analysis.ipynb
```

The scripts save charts to the `visualizations/` folder.

## Important Reporting Note
Do not claim a fixed percentage improvement unless it is calculated from the final dataset and a clearly defined metric. The scripts print the actual metrics so your CV/README can report verified results.

## Skills Demonstrated
Python • Pandas • NumPy • Statsmodels • Scikit-learn • Regression • Statistical Testing • F-test • R² • Adjusted R² • Heteroscedasticity • Weighted Least Squares • Data Visualization
